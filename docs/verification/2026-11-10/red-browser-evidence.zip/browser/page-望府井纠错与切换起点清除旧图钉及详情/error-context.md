# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page.spec.cjs >> 望府井纠错与切换起点清除旧图钉及详情
- Location: tests/page.spec.cjs:70:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  locator('#map')
Expected: visible
Received: hidden
Timeout:  3000ms

Call log:
  - Expect "toBeVisible" locator('#map') with timeout 3000ms
  - waiting for locator('#map')
    10 × locator resolved to <div id="map" hidden="" aria-label="百度地图"></div>
       - unexpected value "hidden"

```

```yaml
- banner:
  - heading "北京探店地图验收" [level=1]
  - paragraph: 输入地点，从十家样本门店中找最近三家。距离采用直线距离。
- text: 起点
- textbox "起点":
  - /placeholder: 例如 王府井
  - text: 王府井
- button "查最近三家"
- button "王府井"
- button "东坝"
- button "大钟寺"
- status: 高德地点检索 · 王府井地铁站 · 十家样本中直线距离最近的三家 · 底图加载失败，当前为位置示意。
- main:
  - img "起点及最近三家门店的相对位置，数字与列表对应": 起 1 2 3 离线位置示意 · 北 ↑
  - list "最近三家门店":
    - listitem:
      - strong: 富春居（北京璞瑄酒店店） · 1.72 km
      - paragraph: 东城区 · 灯市口 · 王府井大街1号璞瑄酒店3层
      - link "探店记录":
        - /url: https://tanwei.org/nearby/poi/2fe17929-0c75-575d-9364-9ebd5aa55b87
      - link "相关 B 站视频":
        - /url: https://www.bilibili.com/video/BV1144y1G7Fo/
    - listitem:
      - strong: 泰丰楼 · 1.92 km
      - paragraph: 西城区 · 大栅栏 · 前门西大街2号楼
      - link "探店记录":
        - /url: https://tanwei.org/nearby/poi/6e490356-c4fc-5253-a35f-5fd5a2084d6b
      - link "相关 B 站视频":
        - /url: https://www.bilibili.com/video/BV1CB4y147BG/
    - listitem:
      - strong: 北京宜宾招待所·餐厅 · 2.82 km
      - paragraph: 西城区 · 宣武门 · 西中胡同28号(宁波宾馆南门斜对面)
      - link "探店记录":
        - /url: https://tanwei.org/nearby/poi/dee9d940-a171-5010-a6c2-5145857abd91
      - link "相关 B 站视频":
        - /url: https://www.bilibili.com/video/BV1wT1WYxEjC/
- group: 百度地图实时验收
```

# Test source

```ts
  1   | const {test, expect} = require('@playwright/test');
  2   | const {readFileSync} = require('node:fs');
  3   | const {join} = require('node:path');
  4   | const {origins, restaurants, resolveFixture} = require('../samples.js');
  5   | const expected = {
  6   |   王府井: {names: ['富春居（北京璞瑄酒店店）', '泰丰楼', '北京宜宾招待所·餐厅'], km: [1.72, 1.92, 2.82]},
  7   |   东坝: {names: ['寂川（西大望路店）', '潇湘阁（三里屯SOHO店）', '老吉堂·吉来（正大中心店）'], km: [8.11, 8.81, 8.93]},
  8   |   大钟寺: {names: ['洪福亮酒家（南草厂街店）', '砂锅居（西四店）', '同和居（月坛店）'], km: [3.74, 5.68, 5.85]}
  9   | };
  10  | const json = (route, value, status = 200) => route.fulfill({status, json: value});
  11  | 
  12  | async function setup(page) {
  13  |   await page.route('https://webapi.amap.com/maps?**', route => route.fulfill({
  14  |     contentType: 'text/javascript', body: readFileSync(join(__dirname, 'mock-sdk.js'), 'utf8')
  15  |   }));
  16  |   await page.route('**/api/amap/config', route => json(route, {
  17  |     jsKey: 'fixture-public-key', serviceHost: '/_AMapService', searchEnabled: true, mapEnabled: true
  18  |   }));
  19  |   await page.route('**/api/amap/status', route => json(route, {enabled: true}));
  20  |   await page.route('**/api/amap/search?**', route => {
  21  |     const input = new URL(route.request().url()).searchParams.get('q');
  22  |     const origin = resolveFixture(input);
  23  |     return json(route, {matches: origin ? [origin] : []});
  24  |   });
  25  |   await page.goto('/');
> 26  |   await expect(page.locator('#map')).toBeVisible();
      |                                      ^ Error: expect(locator).toBeVisible() failed
  27  |   await expect(page.locator('#results > li')).toHaveCount(3);
  28  | }
  29  | async function search(page, query) {
  30  |   await page.getByLabel('起点', {exact: true}).fill(query);
  31  |   await page.getByRole('button', {name: '查最近三家', exact: true}).click();
  32  | }
  33  | async function verify(page, name) {
  34  |   const {names, km} = expected[name];
  35  |   await expect(page.locator('#status')).toContainText(origins[name].name);
  36  |   const markers = page.locator('#map .map-pin');
  37  |   await expect(markers).toHaveCount(4);
  38  |   await expect(page.locator('#map [data-marker-index="0"]')).toContainText('起');
  39  |   const data = await page.evaluate(() => ({
  40  |     positions: window.sdkMap.markers.map(marker => marker.position), fitted: window.sdkMap.fitted
  41  |   }));
  42  |   expect(data.positions[0]).toEqual([origins[name].lng, origins[name].lat]);
  43  |   expect(data.fitted).toEqual(data.positions);
  44  |   for (let i = 0; i < 3; i++) {
  45  |     const shop = restaurants.find(item => item.name === names[i]);
  46  |     const item = page.locator('#results > li').nth(i);
  47  |     await expect(item).toContainText(names[i]);
  48  |     await expect(item).toContainText(shop.address);
  49  |     expect(Math.abs(Number((await item.innerText()).match(/([\d.]+) km/)[1]) - km[i])).toBeLessThanOrEqual(0.05);
  50  |     expect(data.positions[i + 1]).toEqual([shop.lng, shop.lat]);
  51  |     const pin = page.locator(`#map [data-marker-index="${i + 1}"]`);
  52  |     await expect(pin).toHaveText(String(i + 1));
  53  |     await pin.click();
  54  |     await expect(item).toHaveAttribute('aria-current', 'true');
  55  |     const info = page.locator('#map .shop-info');
  56  |     await expect(info).toContainText(shop.name);
  57  |     await expect(info).toContainText(shop.address);
  58  |     await expect(info).toContainText('km');
  59  |     await expect(info.getByRole('link', {name: '探店记录'})).toHaveAttribute('href', shop.source);
  60  |     await expect(item.getByRole('link', {name: '探店记录'})).toHaveAttribute('href', shop.source);
  61  |   }
  62  | }
  63  | 
  64  | for (const name of Object.keys(expected)) test(`${name}：同屏四个图钉、编号排序、分店地址距离与出处`, async ({page}) => {
  65  |   await setup(page);
  66  |   await search(page, name);
  67  |   await verify(page, name);
  68  |   await page.screenshot({path: `test-results/fixture-${name}.png`, fullPage: true});
  69  | });
  70  | test('望府井纠错与切换起点清除旧图钉及详情', async ({page}) => {
  71  |   await setup(page);
  72  |   await search(page, ' 北京望府井 ');
  73  |   await verify(page, '王府井');
  74  |   await search(page, '东坝');
  75  |   await expect(page.locator('#map .shop-info')).toHaveCount(0);
  76  |   await verify(page, '东坝');
  77  |   await expect(page.locator('#results')).not.toContainText('富春居');
  78  | });
  79  | test('旧请求晚返回时只保留最新起点', async ({page}) => {
  80  |   await setup(page);
  81  |   let release;
  82  |   const held = new Promise(resolve => { release = resolve; });
  83  |   let arrived;
  84  |   const started = new Promise(resolve => { arrived = resolve; });
  85  |   await page.route('**/api/amap/search?**', async route => {
  86  |     const input = new URL(route.request().url()).searchParams.get('q');
  87  |     if (input === '王府井') { arrived(); await held; }
  88  |     await json(route, {matches: [origins[input]]});
  89  |   });
  90  |   await search(page, '王府井');
  91  |   await started;
  92  |   await search(page, '东坝');
  93  |   await verify(page, '东坝');
  94  |   const late = page.waitForResponse(response => response.url().includes('q=%E7%8E%8B'));
  95  |   release();
  96  |   await late;
  97  |   await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  98  |   await verify(page, '东坝');
  99  | });
  100 | test('歧义地点先选择再绘图，地址可区分', async ({page}) => {
  101 |   await setup(page);
  102 |   await page.route('**/api/amap/search?**', route => json(route, {matches: [
  103 |     {...origins.王府井, name: '同名地点', address: '东城区 王府井大街'},
  104 |     {...origins.大钟寺, name: '同名地点', address: '海淀区 大钟寺路'}
  105 |   ]}));
  106 |   await search(page, '同名地点');
  107 |   await expect(page.locator('#results > li')).toHaveCount(0);
  108 |   await expect(page.locator('#map .map-pin')).toHaveCount(0);
  109 |   await page.getByRole('button', {name: '同名地点 · 海淀区 大钟寺路'}).click();
  110 |   await expect(page.locator('#results > li').first()).toContainText('洪福亮酒家');
  111 |   await expect(page.locator('#map .map-pin')).toHaveCount(4);
  112 | });
  113 | test('无结果、接口失败清空旧结果，可重新搜索', async ({page}) => {
  114 |   await setup(page);
  115 |   await search(page, '没有这个地方');
  116 |   await expect(page.locator('#status')).toContainText('未找到');
  117 |   await expect(page.locator('#map .map-pin')).toHaveCount(0);
  118 |   await expect(page.locator('#results > li')).toHaveCount(0);
  119 |   await page.route('**/api/amap/search?**', route => json(route, {error: '失败'}, 502));
  120 |   await search(page, '东坝');
  121 |   await expect(page.locator('#status')).toContainText('失败');
  122 |   await expect(page.locator('#map .map-pin')).toHaveCount(0);
  123 |   await expect(page.locator('#results > li')).toHaveCount(0);
  124 |   await page.unroute('**/api/amap/search?**');
  125 |   await page.route('**/api/amap/search?**', route => json(route, {matches: [origins.大钟寺]}));
  126 |   await page.getByRole('button', {name: '重试搜索'}).click();
```